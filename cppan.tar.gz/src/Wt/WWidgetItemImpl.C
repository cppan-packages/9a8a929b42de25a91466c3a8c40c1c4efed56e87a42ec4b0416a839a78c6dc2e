/*
 * Copyright (C) 2016 Emweb bvba, Kessel-Lo, Belgium.
 *
 * See the LICENSE file for terms of use.
 */

#include "Wt/WWidgetItemImpl.h"

namespace Wt {

WWidgetItemImpl::~WWidgetItemImpl()
{ }

}
